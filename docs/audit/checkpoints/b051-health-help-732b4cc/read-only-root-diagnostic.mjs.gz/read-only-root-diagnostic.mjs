import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {productCatalog} from '/workspace/Forsikringsapp/lib/product-catalog.ts';
import {catalogFactSources,enrichExtractedAgreementWithCatalog} from '/workspace/Forsikringsapp/lib/catalog-enrichment.ts';
import {documentPipeline} from '/workspace/Forsikringsapp/tests/helpers/supporting-terms.mjs';
const oracle=JSON.parse(readFileSync('/workspace/Forsikringsapp/docs/audit/checkpoints/b051-health-help-732b4cc/source-oracle.json'));
const baseline=structuredClone(productCatalog),key=oracle.key;
const baselineFact=baseline.facts[oracle.owner].find(f=>f.key===key);baselineFact.value=oracle.previous_value;baselineFact.source.page=12;
const ids=['gjensidige-hus','gjensidige-hus-pluss'],date=new Date('2026-10-07T12:00:00Z');
const results=[];
for(const [revision,catalog]of[['unchanged-baseline',baseline],['preserved-candidate',productCatalog]])for(const id of ids){
 const p=catalog.products.find(x=>x.productId===id),raw=catalog.facts[oracle.owner].find(f=>f.key===key);
 const fixture={company:'Gjensidige',totalAnnualPremium:null,insurances:[{company:'Gjensidige',type:'Hus',productName:p.name,annualPremium:null,deductible:null,coverageSummary:null,importantTerms:[],addOns:[]}]};
 const firstInsurance=enrichExtractedAgreementWithCatalog(fixture,date,undefined,undefined,catalog).insurances[0];
 const secondInsurance=enrichExtractedAgreementWithCatalog({...fixture,insurances:[firstInsurance]},date,undefined,undefined,catalog).insurances[0];
 const first=firstInsurance.importantTerms.find(t=>t.key===key),second=secondInsurance.importantTerms.find(t=>t.key===key);
 const fields=[...new Set([...Object.keys(first),...Object.keys(second)])];
 const recorded=fields.filter(k=>!Object.is(first[k],second[k])&&(JSON.stringify(first[k])!==JSON.stringify(second[k])||Object.hasOwn(first,k)!==Object.hasOwn(second,k)));
 const observed=fields.filter(k=>JSON.stringify(first[k])!==JSON.stringify(second[k])||Object.hasOwn(first,k)!==Object.hasOwn(second,k));
 assert.deepEqual(recorded,['coverageOrigin','overriddenBase']);assert.deepEqual(observed,['coverageOrigin','structuredValue','deductibleClassification','overriddenBase']);
 assert.deepEqual(first.source,raw.source);assert.deepEqual(first.sources,catalogFactSources(raw));assert.deepEqual(second.source,first.source);assert.deepEqual(second.sources,first.sources);
 for(const field of ['structuredValue','deductibleClassification']){assert.equal(Object.hasOwn(first,field),true);assert.equal(first[field],undefined);assert.equal(Object.hasOwn(second,field),false);assert.equal(second[field],undefined);}
 const record={...fixture.insurances[0],canonicalProductName:p.name,documentRole:'individual_agreement',agreementPeriod:null,objectIdentifiers:[],documentIndices:[1],importantTerms:[]};
 const save=productCatalog.facts;let documentResult;
 try{productCatalog.facts=catalog.facts;documentResult=documentPipeline([[record]],'existing').insuranceData;}finally{productCatalog.facts=save;}
 const term=documentResult.insurances[0].importantTerms.find(t=>t.name===oracle.label);assert.ok(term);assert.equal(term.value,raw.value);assert.deepEqual(term.sources,catalogFactSources(raw));
 let shadowFailure;try{catalogFactSources(documentResult);}catch(e){shadowFailure={name:e.name,message:e.message};}
 assert.deepEqual(shadowFailure,{name:'TypeError',message:"Cannot read properties of undefined (reading 'documentId')"});
 results.push({revision,id,source_shadow_failure:shadowFailure,actual_pipeline_source_contract_preserved:true,term_value:term.value,term_sources:term.sources,flawed_metadata_comparator_result:recorded,actual_field_presence_transitions:observed,undefined_presence:['structuredValue','deductibleClassification'].map(field=>({field,first_present:Object.hasOwn(first,field),second_present:Object.hasOwn(second,field),both_values_undefined:true}))});
}
console.log(JSON.stringify({status:'PASS_DIAGNOSTICS_ONLY_NO_CORRECTION',cases:results},null,2));
