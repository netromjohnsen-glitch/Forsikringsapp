from pathlib import Path
import json
R=Path('/workspace/Forsikringsapp');O=R/'docs/audit/checkpoints/b051-health-help-732b4cc';o=json.loads((O/'source-oracle.json').read_text())
p=R/'lib/gjensidige-hus-catalog.ts';s=p.read_text();old='["service.helsehjelp", "Helsehjelp 24/7", '+json.dumps(o['previous_value'],ensure_ascii=False)+', "Helsehjelp 24/7", 12]';new='["service.helsehjelp", "Helsehjelp 24/7", '+json.dumps(o['value'],ensure_ascii=False)+', "Helsehjelp 24/7", 11]';assert s.count(old)==1;p.write_text(s.replace(old,new))
(R/'tests/helpers/b051-health-help.mjs').write_text('''import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
export const healthOracle=JSON.parse(readFileSync(new URL('../../docs/audit/checkpoints/b051-health-help-732b4cc/source-oracle.json',import.meta.url)));
export function transformHealthHelpRows(rows,owner){
 if(owner!==healthOracle.owner)return rows;
 assert.equal(rows.filter(f=>f.key===healthOracle.key).length,1);
 return rows.map(f=>{
  if(f.key!==healthOracle.key)return f;
  assert.equal(f.label,healthOracle.label);assert.equal(f.value,healthOracle.previous_value);
  assert.deepEqual([f.source.page,f.source.section],healthOracle.previous_primary);
  return {...f,value:healthOracle.value,source:{...f.source,page:healthOracle.primary[0]}};
 });
}
export function applyHealthHelp(catalog){
 const expected=structuredClone(catalog);
 expected.facts[healthOracle.owner]=transformHealthHelpRows(expected.facts[healthOracle.owner],healthOracle.owner);
 return expected;
}
''')
p=R/'tests/helpers/b051-liability.mjs';s=p.read_text();s="import {applyHealthHelp} from './b051-health-help.mjs';\n"+s;s=s.replace('export const baselineCatalog=previousCatalog;','export const baselineCatalog=applyHealthHelp(previousCatalog);');p.write_text(s)
for n in ['garden','events-buildings','craftsmanship','settlement-age','recovery-benefits','physical-exclusions']:
 p=R/'tests'/f'remediation-b-051-{n}.test.mjs';s=p.read_text();s="import {applyHealthHelp} from './helpers/b051-health-help.mjs';\n"+s
 # Wrap complete independent prior transformations in both baseline and expected layers.
 pos=0
 while True:
  start=s.find('applyLiability(',pos)
  if start<0:break
  i=start+len('applyLiability(');depth=1
  while depth:
   if s[i]=='(':depth+=1
   elif s[i]==')':depth-=1
   i+=1
  s=s[:start]+'applyHealthHelp('+s[start:i]+')'+s[i:];pos=i+len('applyHealthHelp(')+1
 p.write_text(s)
p=R/'tests/remediation-b-050.test.mjs';s=p.read_text();s="import {transformHealthHelpRows} from './helpers/b051-health-help.mjs';\n"+s
old='transformLiabilityRows(transformPhysicalRows(transformRecoveryRows(transformSettlementRows(transformCraftRows(expected, component), component), component), component, {jsonSnapshot:true}), component)';assert s.count(old)==1;s=s.replace(old,'transformHealthHelpRows('+old+', component)');p.write_text(s)
fps=[('4dbde0cf9f9f467f2138bb70edf8df3e51addbb158f8330d89e40a58bf7dc752','d5c72d2f6ab94d0b3e4fd96343d5117ec357f775c5090515f534d4a9b18baa2e'),('e2dde9decd0cc64db060cc2ce57421741ff51239de95107264e84cf7388ce489','385845464c7ec23331a28d1634f89c92d7bf693c27eab3084347a276487906ee'),('924f9f29873c4356ad3787e755efeb6ffb13dd5300af42352bb3958ab6bc67bd','29cdf599445370bc905a23455a4ad2ffbf3ed7dd6647ed6948692d1c85483525')]
for n in ['nito-remediation-b020','remediation-b-051-liability']:
 p=R/'tests'/f'{n}.test.mjs';s=p.read_text()
 for a,b in fps:assert s.count(a)==1;s=s.replace(a,b)
 p.write_text(s)
p=R/'tests/gjensidige-hus-catalog.test.mjs';s=p.read_text();assert s.count('/videolege/')==1;p.write_text(s.replace('/videolege/',r'/fri bruk av videokonsultasjon med allmenlege hos Dr\.Dropin hele døgnet – alle dager/i'))
# Permanent health matrix: reuse baseline-proven input modes and actual functions,
# with historical oracle + explicit source transform as the independent expectation.
s=Path('/tmp/b051-health-probes.mjs').read_text()
s=s.replace("import assert from 'node:assert/strict';", "import assert from 'node:assert/strict';\nimport test from 'node:test';\nimport {execFileSync} from 'node:child_process';\nimport {healthOracle,applyHealthHelp} from './helpers/b051-health-help.mjs';\nimport {applyLiability,assertLiabilityCatalog} from './helpers/b051-liability.mjs';")
s=s.replace("import {expectedCatalog as oldOracle} from '/workspace/Forsikringsapp/tests/helpers/b051-liability.mjs';", "import {expectedCatalog as previousCatalog} from '../docs/audit/checkpoints/b051-physical-exclusions-0be8fad/expected-catalog.mjs';\nconst oldOracle=applyLiability(previousCatalog);\nconst expectedCatalog=applyHealthHelp(oldOracle);")
s=s.replace('/workspace/Forsikringsapp/lib/','../lib/').replace('/workspace/Forsikringsapp/tests/helpers/','./helpers/')
s=s.replace('const baseline=structuredClone(productCatalog),candidate=structuredClone(baseline),date=', 'const baseline=structuredClone(oldOracle),candidate=productCatalog,date=')
s=s.replace("const value=readFileSync('/tmp/b051-health-value.txt','utf8').trim();",'const value=healthOracle.value;')
s=s.replace("const after=candidate.facts.gjensidigeHusStandard.find(f=>f.key===key);\nafter.value=value;after.source={...before.source,page:11,section:'Helsehjelp 24/7'};", "const expectedFact=expectedCatalog.facts.gjensidigeHusStandard.find(f=>f.key===key);\nconst after={...expectedFact,source:{...expectedFact.source,productCode:undefined}};")
s=s.replace("const sample=[],failures=[];let n=0;const check=(name,fn)=>{try{fn();n++;}catch(e){failures.push({name,error:String(e),stack:e.stack});}};", "const sample=[];let n=0;const check=(name,fn)=>test('R-051-HEALTH-'+(++n)+':'+name,fn);")
s=s[:s.index("console.log(JSON.stringify({status:")]
# Assert the known alias and all meaningful repeat fields rather than demanding
# equality of metadata whose baseline transition is part of the established contract.
needle='assert.deepEqual(b.addOnIds,a.addOnIds);'
addition="assert.deepEqual(state(bb).filter(x=>!state(b).some(y=>x.id===y.id)),[{id:'rettshjelp.dekning',status:'selected',conflict:false}]);"
s=s.replace(needle,needle+addition,1)
# Add strict source/raw, original contracts, four bindings, immutable receipts and fingerprints.
s+='''\nconst audit=new URL('../docs/audit/checkpoints/b051-health-help-732b4cc/',import.meta.url);
const authorization=JSON.parse(readFileSync(new URL('authorization.json',audit)));
check('independent-full-field-reverse',assertLiabilityCatalog);
check('raw-source-reference-and-only-one-row',()=>{
 const actual=candidate.facts.gjensidigeHusStandard.filter(f=>f.key===key);assert.equal(actual.length,1);
 assert.deepEqual(actual[0],after);assert.equal(Object.hasOwn(actual[0].source,'productCode'),true);
 assert.equal(actual[0].source.productCode,undefined);assert.equal(Object.hasOwn(actual[0].source,'sourceType'),false);
 assert.deepEqual(before,{...expectedFact,value:healthOracle.previous_value,source:{...expectedFact.source,page:12}});
 assert.equal(candidate.facts.gjensidigeHusPluss.some(f=>f.key===key),false);
});
const layouts=[];
for(const frozen of authorization.frozen_sources)check('frozen-source:'+frozen.identity,()=>{
 const path=new URL('../'+frozen.path,import.meta.url);assert.equal(digestBytes(readFileSync(path)),frozen.sha256);
 const registered=candidate.sources[frozen.identity];assert.equal(registered.sha256,frozen.sha256);assert.equal(registered.insuranceType,'Hus');assert.equal(registered.company,'Gjensidige');assert.equal(registered.effectiveFrom,'');assert.equal(Object.hasOwn(registered,'sourceType'),false);
 const raw=execFileSync('pdftotext',['-layout','-f',String(frozen.page),'-l',String(frozen.page),path.pathname,'-'],{encoding:'utf8'});layouts.push(raw);
 const text=raw.replace(/\\s+/gu,' ');
 for(const phrase of ['Helsehjelp 24/7 er knyttet til forsikring av Hus- og Personforsikringer','I tillegg til forsikringstaker','Ektefelle eller samboer med felles adresse i Folkeregisteret','utdanning/førstegangstjeneste, og ikke har meldt adresseendring','Barn som er en del av den faste husstanden, men er folkeregistrert på annen adresse pga. delt foreldreansvar','I hele verden','Forsikringen gir alle i husstanden','Fri bruk av videokonsultasjon med allmenlege','hos Dr.Dropin hele døgnet - alle dager','Kostnadsfri videokonsultasjon med psykolog hos Dr.Dropin for å forebygge hverdagsutfordringer. En konsultasjon pr husstandsmedlem per 12 mnd','Fri bruk av digitale selvhjelpsprogrammer som tilbys gjennom Dr.Dropin','Kostnadsfri videokonsultasjon med fysioterapeut hos Dr.Dropin for å forebygge muskel og skjelettplager. En konsultasjon per husstandsmedlem per 12 mnd.','Rabatt på utvalgte tjenester hos hos Dr.Dropin både digitalt og fysisk der Dr.Dropin har lokasjoner. Les mer om hvilke tjenester dette gjelder på våre nettsider','Digital Veiviser på Din side/gjensidige.no','det offentlige helsevesen','tilgjengelige behandlingssteder','beliggenhet','ventetid','Akutt og øyeblikkelig hjelp','Behandlingsutgifter på sykehus og klinikker'])assert.ok(text.includes(phrase),phrase);
 assert.equal(value.includes('Personforsikringer'),false);
});
check('identical-Standard11-and-Plus12-contract',()=>assert.equal(layouts[0],layouts[1]));
check('four-exact-original-bindings',()=>{
 assert.equal(authorization.original_bindings.length,4);assert.equal(authorization.signatures.length,2);
 const preflight=JSON.parse(readFileSync(new URL('../docs/audit/checkpoints/rv02-b071-b051-f829dd3/b051-preflight.json',import.meta.url)));
 const pairs=[['0eda923b4090cf6c','GAP-2108','SF-3021','gjensidige-hus'],['0eda923b4090cf6c','GAP-2167','SF-3108','gjensidige-hus-pluss'],['8a1beb3695ddb2fd','GAP-2109','SF-3023','gjensidige-hus'],['8a1beb3695ddb2fd','GAP-2168','SF-3110','gjensidige-hus-pluss']];
 assert.deepEqual(authorization.original_bindings.map(b=>[b.signature,b.GAP,b.SF,b.product[3]]),pairs);
 for(const row of authorization.signatures){assert.deepEqual(row,preflight.signatures.find(x=>x.signature===row.signature_id).original_binding);}
});
check('all-54-immutable-receipts',()=>{
 const prior=JSON.parse(readFileSync(new URL('prior-receipts.json',audit)));assert.equal(prior.length,54);assert.equal(new Set(prior.map(x=>x.signature)).size,54);
 for(const entry of prior)assert.equal(digestBytes(readFileSync(new URL('../'+entry.path,import.meta.url))),entry.sha256);
});
check('exact-isolation-counts',()=>{assert.equal(protectedRaw,4158);assert.equal(untouched,317);assert.equal(otherProducts,202);});
check('independent-three-fingerprint-differences',()=>{
 assert.deepEqual(fps.map(x=>x.before),['4dbde0cf9f9f467f2138bb70edf8df3e51addbb158f8330d89e40a58bf7dc752','e2dde9decd0cc64db060cc2ce57421741ff51239de95107264e84cf7388ce489','924f9f29873c4356ad3787e755efeb6ffb13dd5300af42352bb3958ab6bc67bd']);
 assert.deepEqual(fps.map(x=>x.after),['d5c72d2f6ab94d0b3e4fd96343d5117ec357f775c5090515f534d4a9b18baa2e','385845464c7ec23331a28d1634f89c92d7bf693c27eab3084347a276487906ee','29cdf599445370bc905a23455a4ad2ffbf3ed7dd6647ed6948692d1c85483525']);
 for(const f of fps){const p=prod(expectedCatalog,f.id);assert.equal(digest(resolveCatalogFacts(p,f.addons,date,null,expectedCatalog).filter(x=>!x.key.startsWith('hus.skadedyr.')&&x.key!=='hus.rate.dekning')),f.after);}
});
function digestBytes(bytes){return createHash('sha256').update(bytes).digest('hex');}
'''
# Add the separate actual extraction pipeline matrix, whose returned source-array
# contract was independently verified on baseline, not inferred from catalog input.
e=Path('/tmp/b051-health-extra.mjs').read_text();e=e[e.index("const record="):e.index("check(()=>{\n assertLiabilityCatalog();")]
e=e.replace('const record=', 'const extractionRecord=').replace('record(id,','extractionRecord(id,').replace('const withCatalog=','const withCatalog=').replace('let checks=0;const check=fn=>{fn();checks++;};const observed=[];', "let extractionChecks=0;const extractionCheck=fn=>test('R-051-HEALTH-extraction-'+(++extractionChecks),fn);const observed=[];")
e=e.replace('check(()=>','extractionCheck(()=>').replace('pipe(base,','pipe(baseline,').replace('pipe(cand,','pipe(candidate,').replace('prod(base,','prod(baseline,').replace('prod(cand,','prod(candidate,').replace('input(base,','input(baseline,').replace('catalogFactSources(proposed)','catalogFactSources(after)')
e=e.replace('d)', 'date)').replace('label', 'healthOracle.label')
# Separate fixture signature uses values (existing input expects term objects).
e=e.replace('...input(baseline,id,[]).insurances[0]', '...input(baseline,id,[]).insurances[0]')
e=e.replace("const input", "const input")
s=s.replace("import {deriveCanonicalCoverages}","import {deriveCanonicalCoverages,coverageStatusFromText}")
s+='\n'+e
# Extra source-only direct fixture and raw repeat metadata controls.
s+='''
for(const id of ids)check('baseline-raw-repeat-metadata:'+id,()=>{
 const first=pick(enrich(candidate,id,[]))[0],second=pick(repeat(candidate,enrich(candidate,id,[])))[0];
 const a=pick(enrich(baseline,id,[]))[0],b=pick(repeat(baseline,enrich(baseline,id,[])))[0];
 const changes=(x,y)=>[...new Set([...Object.keys(x),...Object.keys(y)])].filter(k=>!Object.is(x[k],y[k])&&(JSON.stringify(x[k])!==JSON.stringify(y[k])||Object.hasOwn(x,k)!==Object.hasOwn(y,k)));
 assert.deepEqual(changes(first,second),changes(a,b));
 assert.deepEqual(changes(first,second),['coverageOrigin','structuredValue','deductibleClassification','overriddenBase']);
 assert.equal(first.coverageOrigin,'catalog');assert.equal(second.coverageOrigin,'document');
 assert.equal(first.structuredValue,undefined);assert.equal(first.deductibleClassification,undefined);assert.deepEqual(first.overriddenBase,[]);
 for(const k of ['structuredValue','deductibleClassification','overriddenBase'])assert.equal(Object.hasOwn(second,k),false);
 assert.deepEqual(pick(repeat(candidate,enrich(candidate,id,['Valgt','Ikke valgt']))).map(t=>t.value),['Valgt','Ikke valgt']);
});
'''
# Use the original extraction fixture's own parameters, not those of raw input.
e_old='canonicalProductName:prod(baseline,id).name,documentRole:role,agreementPeriod:null,objectIdentifiers:[],documentIndices:[1],importantTerms:values.map(value=>({name:healthOracle.label,value,documentIndices:[1]}))'
assert e_old in s
# Distinct extraction helpers avoid redeclaring raw/probe record function.
s=s.replace('const extractionRecord=(id,role,values)=>', 'const extractionRecord=(id,role,values)=>')
(R/'tests/remediation-b-051-health-help.test.mjs').write_text(s)
print('Authorized single production row and independent planned expectations written')
