from pathlib import Path
import json,csv,hashlib,subprocess,gzip
R=Path('/workspace/Forsikringsapp'); O=R/'docs/audit/checkpoints/b051-liability-3947e4e'; O.mkdir()
H='3947e4e90b9ab09ea46dda659a2271d956ae1dd3'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==H
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,v): (O/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
prompt=Path('/workspace/attachments/096bebfa-eadb-4bf6-82f2-4a528bb9afbe/Innlimt tekst.txt').read_bytes()
normalized=prompt.replace(b'\r\n',b'\n');assert normalized.replace(b'\n',b'\r\n')==prompt
(O/'authorization.md').write_bytes(normalized+b'\n' if not normalized.endswith(b'\n') else normalized)
reg={r['signature_id']:r for r in csv.DictReader((R/'docs/audit/legacy-local/source-catalog-remediation-triage/p1-triage.csv').open())};assert len(reg)==1589
pre=json.loads((R/'docs/audit/checkpoints/rv02-b071-b051-f829dd3/b051-preflight.json').read_text())
def find(v):
 if isinstance(v,dict):
  if v.get('signature')=='275365b3ec2971df' and 'original_source_evidence' in v:return v
  for z in v.values():
   f=find(z)
   if f:return f
 if isinstance(v,list):
  for z in v:
   f=find(z)
   if f:return f
s=find(pre);assert s['original_binding']==reg[s['signature']]
assert [(e['finding_id'],e['source_fact_id'])for e in s['original_source_evidence']]==[('GAP-2104','SF-3017'),('GAP-2163','SF-3104')]
old=R/'docs/audit/checkpoints/b051-physical-exclusions-0be8fad'
prior=json.loads((old/'prior-receipts.json').read_text())
for sig in ['a4e5c76df5cbf2af','af3a3ee673fedc83']:
 p=old/f'completion-receipt-{sig}.json';prior.append({'signature':sig,'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())})
for r in prior:
 b=(R/r['path']).read_bytes();assert sha(b)==r['sha256'];receipt=json.loads(b);assert receipt['status']=='PASS' and receipt['signature']==r['signature'];assert receipt['original_binding']==reg[r['signature']]
cp=json.loads((old/'checkpoint.json').read_text());assert {r['signature']for r in prior}==set(cp['documented_campaign_signatures']) and len(prior)==53
assert cp['HARNESS_AUTONOMY_V1']['used']==29
save('prior-receipts.json',prior)
value=json.loads(Path('/tmp/b051-liability-preflight-results.json').read_text())['proposal']['value']
row=s['current_raw_catalog_facts'][0]['fact']
save('source-oracle.json',{'key':'hus.ansvar.dekning','owner':'gjensidigeHusStandard','label':'Ansvar som eier','previous_value':row['value'],'previous_primary':[7,'Ansvar'],'value':value,'primary':[6,'Ansvar – Dekkes / Dekkes ikke'],'independent_basis':'Complete original Ansvar columns Standard PDF6 and Pluss PDF7, reviewed before production write; exact user-authorized preflight value','build_insurance_not_imported':True})
source_evidence=[]
for e,page in zip(s['original_source_evidence'],[6,7]):
 p=R/e['artifact'];assert sha(p.read_bytes())==e['sha256']
 command=['pdftotext','-layout','-f',str(page),'-l',str(page),e['artifact'],'-'];b=subprocess.check_output(command,cwd=R)
 name='source-'+('standard' if page==6 else 'plus')+'-layout.txt.gz';(O/name).write_bytes(gzip.compress(b,mtime=0))
 source_evidence.append({'path':e['artifact'],'sha256':e['sha256'],'page':page,'command':command,'layout':name,'original_output_sha256':sha(b)})
assert gzip.decompress((O/source_evidence[0]['layout']).read_bytes())==gzip.decompress((O/source_evidence[1]['layout']).read_bytes())
files=['lib/gjensidige-hus-catalog.ts','tests/remediation-b-051-liability.test.mjs','tests/helpers/b051-liability.mjs','tests/nito-remediation-b020.test.mjs','tests/remediation-b-050.test.mjs','tests/remediation-b-051.test.mjs',*[f'tests/remediation-b-051-{n}.test.mjs'for n in ['garden','events-buildings','craftsmanship','settlement-age','recovery-benefits','physical-exclusions']]]
auth={'classification':'EXPLICIT_IMPLEMENTATION_AUTHORIZATION','baseline':H,'signature':'275365b3ec2971df','original_binding':reg['275365b3ec2971df'],'source_evidence':s['original_source_evidence'],'frozen_sources':source_evidence,'application_files':files,'audit_directory':str(O.relative_to(R)),'status_file':'docs/development-agent/current-project-status.md','permitted_production_delta':'Only existing gjensidigeHusStandard/hus.ansvar.dekning value and primary page/section; Pluss inherits','planned_test_changes':'One independent literal source transform, three B020 fingerprints, named B050/B051 full-field/reverse compatibility contracts, new permanent liability matrix','HARNESS_AUTONOMY_V1':{'used':29,'ordinary_limit':12,'scope_used':0,'capacity_for_other_roots':0},'historical_counters':'UNCHANGED','global_resolved_open':'UNKNOWN','P2_credit':0,'holds_origin':str((old/'checkpoint.json').relative_to(R)),'publication':'Atomic commit/push only after complete PASS using existing secured publish.py; no deploy or later scope','original_prompt_sha256':sha(prompt),'original_prompt_bytes':len(prompt),'stored_prompt_newlines':'LF; original upload CRLF, content unchanged','existing_runner':'docs/audit/checkpoints/b051-physical-exclusions-0be8fad/run-final-gates.py','runner_parameter_adaptation':'Reuse original run function, override BASE/OUT/APP in memory; do not mutate historic runner/output','new_generators':False}
save('authorization.json',auth)
save('preflight.json',{'status':'PASS','baseline':H,'clean_before':True,'staged_before':0,'prior_receipts_count':53,'all_original_bindings_verified':True,'original_registry_unique':1589,'source_hashes':'PASS','identical_standard_pdf6_plus_pdf7_extraction':True,'scope_authorized_only':True,'HARNESS_AUTONOMY_V1_used':29,'planned_compatibility_updates_not_correction_roots':True})
print('Preflight/source/binding/53 receipt checks PASS; authorization recorded before production')
